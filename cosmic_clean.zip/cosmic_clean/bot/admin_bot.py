#!/usr/bin/env python3
# bot/admin_bot.py — COSMIC TOOLS Telegram Admin Bot
# Talks to your deployed backend for key management.
#
# pip install python-telegram-bot==20.7 requests
#
# Required env vars (never hardcode in source):
#   BOT_TOKEN      — from @BotFather
#   ADMIN_ID       — your numeric Telegram user ID (@userinfobot)
#   SITE_URL       — e.g. https://your-site.netlify.app
#   ADMIN_TOKEN    — matches ADMIN_TOKEN env var on your backend

from __future__ import annotations
import os, logging, requests
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler,
    MessageHandler, filters, ContextTypes,
)

logging.basicConfig(
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

# ── config from env ────────────────────────────────────────────────────────────
# All secrets come from environment variables only.
# Never set defaults for secrets here.

def _require(var: str) -> str:
    val = os.environ.get(var)
    if not val:
        raise RuntimeError(f"Missing required env var: {var}")
    return val

BOT_TOKEN   = _require("BOT_TOKEN")
ADMIN_ID    = int(_require("ADMIN_ID"))
SITE_URL    = _require("SITE_URL").rstrip("/")
ADMIN_TOKEN = _require("ADMIN_TOKEN")   # sent as X-Admin-Token header, never in body

UNAUTH_MSG = (
    "⚠️ You are not authorized to use this bot.\n\n"
    "Contact @LEGITCosmicDev for access."
)


# ── API helpers ────────────────────────────────────────────────────────────────

def _api(path: str, method: str = "GET", json_body: dict | None = None) -> dict:
    # Admin token is always a header, never in the body.
    headers = {
        "Content-Type": "application/json",
        "X-Admin-Token": ADMIN_TOKEN,
    }
    url = f"{SITE_URL}/api/{path}"
    try:
        if method == "POST":
            r = requests.post(url, json=json_body or {}, headers=headers, timeout=15)
        else:
            r = requests.get(url, headers=headers, timeout=15)
        r.raise_for_status()
        return r.json()
    except requests.HTTPError as e:
        return {"ok": False, "error": f"HTTP {e.response.status_code}"}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def api_keys_list() -> dict:
    return _api("keys-list")

def api_create_key(uses: int) -> dict:
    return _api("keys-create", "POST", {"uses": uses})

def api_revoke_key(key: str) -> dict:
    return _api("keys-revoke", "POST", {"key": key})

def api_sms_status() -> dict:
    return _api("sms-status")


# ── auth decorator ─────────────────────────────────────────────────────────────

def admin_only(func):
    async def wrapper(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        uid = update.effective_user.id if update.effective_user else 0
        if uid != ADMIN_ID:
            await update.effective_message.reply_text(UNAUTH_MSG)
            return
        return await func(update, ctx)
    wrapper.__name__ = func.__name__
    return wrapper


# ── keyboards ──────────────────────────────────────────────────────────────────

def main_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔑 Generate Key",  callback_data="menu_genkey")],
        [InlineKeyboardButton("📋 List Keys",     callback_data="menu_listkeys")],
        [InlineKeyboardButton("🗑 Revoke Key",    callback_data="menu_revoke")],
        [InlineKeyboardButton("📊 SMS Status",    callback_data="menu_smsstatus")],
        [InlineKeyboardButton("📈 Stats",         callback_data="menu_stats")],
    ])


# ── /start ─────────────────────────────────────────────────────────────────────

@admin_only
async def start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await update.effective_message.reply_text(
        "⚡ *COSMIC TOOLS — Admin Panel*\n\nChoose an action:",
        parse_mode="Markdown",
        reply_markup=main_kb(),
    )


# ── callbacks ──────────────────────────────────────────────────────────────────

@admin_only
async def button(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q   = update.callback_query
    cb  = q.data
    msg = q.message
    await q.answer()

    if cb == "menu_genkey":
        await msg.edit_text(
            "🔑 *Generate Key*\n\nSelect use count:",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("x1 use",              callback_data="genkey_1")],
                [InlineKeyboardButton("x5 uses",             callback_data="genkey_5")],
                [InlineKeyboardButton("x10 uses",            callback_data="genkey_10")],
                [InlineKeyboardButton("x50 uses",            callback_data="genkey_50")],
                [InlineKeyboardButton("♾ Unlimited (99999)", callback_data="genkey_99999")],
                [InlineKeyboardButton("« Back",              callback_data="menu_back")],
            ]),
        )
        return

    if cb.startswith("genkey_"):
        uses = int(cb.split("_")[1])
        await msg.edit_text("⏳ Generating key...", parse_mode=None)
        result = api_create_key(uses)
        if result.get("ok"):
            key = result["key"]
            await msg.edit_text(
                f"✅ *Key Generated*\n\n`{key}`\n\nUses: `{uses}`\nStatus: Active",
                parse_mode="Markdown",
            )
        else:
            await msg.edit_text(f"❌ Error: {result.get('error', 'unknown')}", parse_mode=None)
        return

    if cb == "menu_listkeys":
        await msg.edit_text("⏳ Fetching keys...", parse_mode=None)
        result = api_keys_list()
        if not result.get("ok"):
            await msg.edit_text(f"❌ {result.get('error', 'Failed to fetch keys')}")
            return
        keys = result.get("keys", {})
        if not keys:
            await msg.edit_text("📋 No keys yet.")
            return
        lines = []
        for k, v in list(keys.items())[-20:]:
            icon  = "✅" if v.get("active") else "❌"
            uses  = v.get("uses_left", 0)
            rdm   = len(v.get("redeemed_by", []))
            uses_display = "∞" if uses == 99999 else str(uses)
            lines.append(f"{icon} `{k}`\n    └ {uses_display} uses · {rdm} redeemed")
        await msg.edit_text(
            "📋 *Keys (last 20)*\n\n" + "\n".join(lines),
            parse_mode="Markdown",
        )
        return

    if cb == "menu_revoke":
        ctx.user_data["state"] = "await_revoke_key"
        await msg.edit_text(
            "🗑 *Revoke Key*\n\nSend the key string to revoke:",
            parse_mode="Markdown",
        )
        return

    if cb == "menu_smsstatus":
        result = api_sms_status()
        lines  = [f"Status: `{result.get('status', 'idle')}`"]
        if result.get("target_number"):
            lines.append(f"Target: `{result['target_number']}`")
        if result.get("total_batches"):
            lines.append(f"Batches: `{result.get('current_batch', 0)}/{result['total_batches']}`")
        if result.get("success") is not None:
            lines.append(f"Success: `{result['success']}` | Failed: `{result.get('failed', 0)}`")
        await msg.edit_text("📊 *SMS Status*\n\n" + "\n".join(lines), parse_mode="Markdown")
        return

    if cb == "menu_stats":
        result = api_keys_list()
        keys   = result.get("keys", {}) if result.get("ok") else {}
        active = sum(1 for v in keys.values() if v.get("active"))
        used   = sum(len(v.get("redeemed_by", [])) for v in keys.values())
        await msg.edit_text(
            f"📈 *Stats*\n\n"
            f"Keys total: `{len(keys)}`\n"
            f"Active keys: `{active}`\n"
            f"Total redeemed: `{used}`",
            parse_mode="Markdown",
        )
        return

    if cb == "menu_back":
        await msg.edit_text(
            "⚡ *COSMIC TOOLS — Admin Panel*\n\nChoose an action:",
            parse_mode="Markdown",
            reply_markup=main_kb(),
        )
        return


# ── text messages ──────────────────────────────────────────────────────────────

@admin_only
async def handle_text(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    state = ctx.user_data.get("state")
    text  = (update.message.text or "").strip()

    if state == "await_revoke_key":
        ctx.user_data.pop("state", None)
        await update.message.reply_text("⏳ Revoking...")
        result = api_revoke_key(text.upper())
        if result.get("ok"):
            await update.message.reply_text(f"✅ Revoked: `{text.upper()}`", parse_mode="Markdown")
        else:
            await update.message.reply_text(f"❌ {result.get('error', 'Failed')}")
        return

    await update.message.reply_text("Send /start to open the admin panel.")


# ── catch-all unauthorized ─────────────────────────────────────────────────────

async def unauthorized_handler(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id if update.effective_user else 0
    if uid != ADMIN_ID:
        await update.effective_message.reply_text(UNAUTH_MSG)


# ── main ───────────────────────────────────────────────────────────────────────

def main():
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(button))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))
    app.add_handler(MessageHandler(filters.ALL, unauthorized_handler))

    logger.info("⚡ COSMIC Admin Bot running (admin: %d)", ADMIN_ID)
    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()
